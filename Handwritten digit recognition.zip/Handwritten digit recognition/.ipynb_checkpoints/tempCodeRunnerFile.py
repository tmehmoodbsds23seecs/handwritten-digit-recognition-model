# Task 1: Backtracking Algorithm for N-Queens

def solve_n_queens_backtracking(N):
    def is_safe(board, row, col):
        for i in range(row):
            if board[i] == col or abs(board[i] - col) == abs(i - row):
                return False
        return True

    def backtrack(row):
        if row == N:
            solutions.append(board[:])
            return
        for col in range(N):
            if is_safe(board, row, col):
                board[row] = col
                backtrack(row + 1)
                board[row] = -1

    board = [-1] * N
    solutions = []
    backtrack(0)
    return solutions

# Task 2: Forward Checking for N-Queens

def solve_n_queens_forward_checking(N):
    def is_safe(board, row, col):
        for i in range(row):
            if board[i] == col or abs(board[i] - col) == abs(i - row):
                return False
        return True

    def forward_check(row, valid_cols):
        if row == N:
            solutions.append(board[:])
            return
        for col in valid_cols[row]:
            if is_safe(board, row, col):
                board[row] = col
                next_valid_cols = [list(cols) for cols in valid_cols]
                for r in range(row + 1, N):
                    if col in next_valid_cols[r]:
                        next_valid_cols[r].remove(col)
                    if col + (r - row) in next_valid_cols[r]:
                        next_valid_cols[r].remove(col + (r - row))
                    if col - (r - row) in next_valid_cols[r]:
                        next_valid_cols[r].remove(col - (r - row))
                forward_check(row + 1, next_valid_cols)
                board[row] = -1

    board = [-1] * N
    solutions = []
    valid_cols = [list(range(N)) for _ in range(N)]
    forward_check(0, valid_cols)
    return solutions

# Testing the functions
if __name__ == "__main__":
    N = int(input("Enter the value of N for the N-Queens problem: "))
    print("\nSolutions using Backtracking for N=", N)
    solutions_bt = solve_n_queens_backtracking(N)
    for solution in solutions_bt:
        print(solution)

    print("\nSolutions using Forward Checking for N=", N)
    solutions_fc = solve_n_queens_forward_checking(N)
    for solution in solutions_fc:
        print(solution)

    print("\nNumber of solutions using Backtracking:", len(solutions_bt))
    print("Number of solutions using Forward Checking:", len(solutions_fc))
